module.exports = {

    database: {
        connectionLimit: 10,
        host: 'localhost',
        user: 'root',
        password: 'Password1',
        database: 'db_links'
    }

};