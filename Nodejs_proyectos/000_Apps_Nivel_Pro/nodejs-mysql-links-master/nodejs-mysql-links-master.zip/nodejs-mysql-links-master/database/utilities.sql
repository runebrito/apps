-- DELETE ALL ROWS
DELETE FROM users;

DROP table links;