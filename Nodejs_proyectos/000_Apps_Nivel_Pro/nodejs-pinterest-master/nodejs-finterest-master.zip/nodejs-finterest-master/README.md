# Finterest
a simple example nodejs and mongodb app based on Pinterest.

![](docs/screenshot.png)