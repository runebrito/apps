# Screenshots
![](docs/screenshot1.png)
![](docs/screenshot2.png)

# Improvements for the Future
- Input Validation (to avoid XSS)
- User Authentication
